package mk.tradesense.predictionservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PredictionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
