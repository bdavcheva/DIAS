package mk.tradesense.stockitemsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockItemsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockItemsServiceApplication.class, args);
	}

}
