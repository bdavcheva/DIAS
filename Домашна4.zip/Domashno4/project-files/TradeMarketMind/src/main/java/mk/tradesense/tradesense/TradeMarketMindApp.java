package mk.tradesense.tradesense;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TradeMarketMindApp {

	public static void main(String[] args) {
		SpringApplication.run(TradeMarketMindApp.class, args);
	}

}
