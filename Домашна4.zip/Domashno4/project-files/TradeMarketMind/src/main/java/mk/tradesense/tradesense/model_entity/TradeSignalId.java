package mk.tradesense.tradesense.model_entity;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class TradeSignalId implements Serializable {
    private String stockCode;
    private Date date;
}
