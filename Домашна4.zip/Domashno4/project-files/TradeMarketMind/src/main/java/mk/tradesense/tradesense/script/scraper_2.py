import requests
from bs4 import BeautifulSoup
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor
import pandas as pd
import psycopg2
from psycopg2.extras import execute_values
import time
import os
from dotenv import load_dotenv

load_dotenv()

DB_CONFIG = {
    "dbname": os.getenv("user_name"),
    "user": os.getenv("user_db"),
    "password": os.getenv("Password_db"),
    "host": os.getenv("Host_db"),
    "port": os.getenv("Port_db")
}
base_url = "https://www.mse.mk/mk/stats/symbolhistory/"
issuer_list = []

def contains_digits(s):
    return any(char.isdigit() for char in s)

def fetch_issuers():
    issuers_url = f"{base_url}kmb"
    with requests.Session() as session:
        response = session.get(issuers_url)
        soup = BeautifulSoup(response.content, "html.parser")
        options = soup.select("#Code option")
        for option in options:
            issuer = option.text.strip()
            if issuer and not contains_digits(issuer):
                issuer_list.append(issuer)

def get_most_recent_scraped_date(conn):
    with conn.cursor() as cur:
        cur.execute("SELECT MAX(date) FROM stock_prices")
        result = cur.fetchone()
        return result[0] if result[0] else None

def complete_missing_dates(sorted_data):
    completed_data = []
    sorted_data = sorted(sorted_data, key=lambda x: (x['Issuer'], datetime.strptime(x['Date'], "%d.%m.%Y") if x['Date'] else datetime.min))

    grouped_by_issuer = {}
    for record in sorted_data:
        issuer = record['Issuer']
        if issuer not in grouped_by_issuer:
            grouped_by_issuer[issuer] = []
        grouped_by_issuer[issuer].append(record)

    for issuer, records in grouped_by_issuer.items():
        records = sorted(records, key=lambda x: datetime.strptime(x['Date'], "%d.%m.%Y"))

        for i in range(len(records) - 1):
            current_record = records[i]
            next_record = records[i + 1]

            current_date = datetime.strptime(current_record['Date'], "%d.%m.%Y")
            next_date = datetime.strptime(next_record['Date'], "%d.%m.%Y")
            while (next_date - current_date).days > 1:
                current_date += timedelta(days=1)
                completed_data.append({
                    "Issuer": current_record['Issuer'],
                    "Date": current_date.strftime("%d.%m.%Y"),
                    "Last Transaction Price": current_record['Last Transaction Price'],
                    "Max": current_record['Max'],
                    "Min": current_record['Min'],
                    "Average Price": current_record['Average Price'],
                    "% Change": '0',
                    "Quantity": '0',
                    "Best Turnover in Denars": '0',
                    "Total Turnover in Denars": '0'
                })

        completed_data.extend(records)

    return completed_data

def insert_data_to_database(conn, stock_data):
    filled_stock_data = complete_missing_dates(stock_data)
    filled_stock_data = sorted(filled_stock_data, key=lambda x: (
    x['Issuer'], datetime.strptime(x['Date'], "%d.%m.%Y") if x['Date'] else datetime.min))

    insert_query = """
        INSERT INTO stock_prices (
            stock_code, date, last_price, max_price, min_price, avg_price,
            percent_change, quantity, turnover_best, total_turnover
        ) VALUES %s
    """

    formatted_data = [
        (
            record['Issuer'],
            datetime.strptime(record['Date'], "%d.%m.%Y") if record['Date'] else None,
            float(record['Last Transaction Price'].replace('.', '').replace(',', '.')) if record['Last Transaction Price'] else None,
            float(record['Max'].replace('.', '').replace(',', '.')) if record['Max'] else None,
            float(record['Min'].replace('.', '').replace(',', '.')) if record['Min'] else None,
            float(record['Average Price'].replace('.', '').replace(',', '.')) if record['Average Price'] else None,
            float(record['% Change'].replace('.', '').replace(',', '.')) if record['% Change'] else 0,
            float(record['Quantity'].replace('.', '').replace(',', '.')) if record['Quantity'] else None,
            float(record['Best Turnover in Denars'].replace('.', '').replace(',', '.')) if record['Best Turnover in Denars'] else None,
            float(record['Total Turnover in Denars'].replace('.', '').replace(',', '.')) if record['Total Turnover in Denars'] else None
        )
        for record in filled_stock_data
    ]

    with conn.cursor() as cur:
        execute_values(cur, insert_query, formatted_data)
    conn.commit()

def retrieve_issuer_data(issuer, start_date, end_date):
    issuer_data = []
    url = f"{base_url}{issuer}"
    with requests.Session() as session:
        payload = {
            "FromDate": start_date.strftime("%d.%m.%Y"),
            "ToDate": end_date.strftime("%d.%m.%Y"),
            "Issuer": issuer
        }
        try:
            response = session.post(url, data=payload)
            soup = BeautifulSoup(response.text, "html.parser")
            table_body = soup.select_one("#resultsTable tbody")
            if not table_body:
                print(f"No data for {issuer} from {start_date} to {end_date}")
                return []
            for row in table_body.find_all("tr"):
                row_data = row.find_all("td")
                if len(row_data) < 9:
                    continue

                record = {
                    "Issuer": issuer,
                    "Date": row_data[0].text.strip() or None,
                    "Last Transaction Price": row_data[1].text.strip() or None,
                    "Max": row_data[2].text.strip() or None,
                    "Min": row_data[3].text.strip() or None,
                    "Average Price": row_data[4].text.strip() or None,
                    "% Change": row_data[5].text.strip() or None,
                    "Quantity": row_data[6].text.strip() or None,
                    "Best Turnover in Denars": row_data[7].text.strip() or None,
                    "Total Turnover in Denars": row_data[8].text.strip() or None,
                }

                record['Max'] = record['Max'] or record['Average Price']
                record['Min'] = record['Min'] or record['Average Price']

                if not all([record["Last Transaction Price"], record["Max"], record["Min"],
                            record["Average Price"]]):
                    continue

                record['% Change'] = record['% Change'] or '0'
                issuer_data.append(record)

        except Exception as e:
            print(f"Error fetching data for {issuer}: {e}")

    return issuer_data

def main():
    conn = psycopg2.connect(**DB_CONFIG)
    fetch_issuers()

    last_scraped_date = get_most_recent_scraped_date(conn)
    start_date = (last_scraped_date + timedelta(days=1)) if last_scraped_date else datetime.now().date() - timedelta(
        days=365 * 10)
    end_date = datetime.now().date()

    date_ranges = [(start_date + timedelta(days=365 * i),
                    min(start_date + timedelta(days=365 * (i + 1)) - timedelta(days=1), end_date)) for i in
                   range((end_date.year - start_date.year) + 1)]

    start_time = time.time()

    if (start_date == end_date):
        print(f"No new data to scrape")
    else:
        with ThreadPoolExecutor(max_workers=50) as executor:
            for issuer in issuer_list:
                results = executor.map(lambda dr: retrieve_issuer_data(issuer, *dr), date_ranges)
                for result in results:
                    if result:
                        insert_data_to_database(conn, result)

    elapsed_time = time.time() - start_time
    print(f"Data scraping and insertion took {elapsed_time:.2f} seconds.")

    conn.close()

if __name__ == "__main__":
    main()
