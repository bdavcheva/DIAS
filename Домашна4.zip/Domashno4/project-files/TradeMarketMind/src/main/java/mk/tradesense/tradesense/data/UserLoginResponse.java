package mk.tradesense.tradesense.data;

import lombok.Data;
import mk.tradesense.tradesense.model_entity.enumerations.Role;

@Data
public class UserLoginResponse {
    private String token;

    private String userName;
    private Role userRole;

    public UserLoginResponse(String token, String userName, Role userRole) {
        this.token = token;
        this.userName = userName;
        this.userRole = userRole;
    }
}
